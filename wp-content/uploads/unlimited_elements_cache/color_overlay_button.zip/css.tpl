#{{uc_id}} a.color-overlay-link
{
  display:inline-block;
  position:relative;
  text-decoration:none;
  overflow:hidden;
}

#{{uc_id}} a span.ue-color-overlay
{
  display:block;
  position:absolute;
  {{position_y}}:0px;
  {{position_x}}:0px;
}

#{{uc_id}} a .ue-btn-txt
{
  position:relative;
  display: flex;
  align-items: center;
  flex-direction: row;
}
#{{uc_id}} a .ue-btn-txt svg
{
  width:1em;
  height:1em;
}