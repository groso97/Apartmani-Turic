<div id="{{uc_id}}" class="blox_btn_group uc-items-wrapper {{uc_filtering_addclass}}" {{uc_filtering_attributes|raw}}>
{% if output == "regular" %}
  {{put_items()}}
{% endif %}  

{% if output == "one_random" %}
  {{put_items("one_random")}}
{% endif %}

{% if output == "shuffle" %}
   {{put_items("shuffle")}}
{% endif %}
</div>