#{{uc_id}} *{
	box-sizing: border-box;
}							  				
		
#{{uc_id}} .uc_content_box_area{
	overflow: hidden;
	position: relative;
  text-align:center;
}


#{{uc_id}} .ue_badge{
  position: absolute;
    top: 16px;
    {% if badge_placement == "right" %}right: -70px;transform: rotate(45deg);{% endif %}	
    {% if badge_placement == "left" %}left: -70px;transform: rotate(-45deg);{% endif %}
    padding: 5px 0px;
    width: 200px;
    text-align: center;
    box-sizing: border-box;
    z-index:2;
}

.ue_badge{
  font-size:10px;
  line-height:1em;
}
	
#{{uc_id}} .uc_thumb{
	margin:0 0 -{{hidden_part}}px;
}

#{{uc_id}} .uc_thumb img{
	max-width:100%;
	width:100%;
	vertical-align:middle;
    object-fit: cover;
}
	
#{{uc_id}} .uc_details{
    padding:0 20px 30px;
    position:relative;
    text-align:center;
	top:{{hidden_part}}px;
    transition:all 0.3s ease 0s;
    width:100%;
    font-weight: 400;
    line-height:1.5em;
}
	
#{{uc_id}} .uc_details .uc_details-icon{
    display: block;
	text-align:center;
	position:relative;
    z-index:1;
}
	
#{{uc_id}} .uc_details .uc_details-icon svg{
  height:1em;
  width:1em;
}
	
#{{uc_id}} .uc_details .uc_btn{
    display: inline-block;
    padding:10px 20px;
    position: relative;
	position:relative;
	top:10px;
    transition: all 0.3s ease-in-out 0s;
	text-decoration:none;
}
	
#{{uc_id}} .uc_content_box_area:hover .uc_details{
	top:0px;
}
	
#{{uc_id}} .uc_content_box_area:hover .uc_details .uc_btn{
	top:0px;
}

.uc_title{
  font-size:21px;
}