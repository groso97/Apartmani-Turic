<div class="ue_marquee" id="{{uc_id}}">
   <div class="marquee_text-container "> 
    <div class="marquee_text">
      {% if enable_link == "true" %}<a href="{{link}}" {{link_html_attributes|raw}}>{% endif %}	
        <{{html_tag}}>{{text|raw}}&nbsp;</{{html_tag}}>
      {% if enable_link == "true" %}</a>{% endif %}	
    </div>
  </div>
</div>