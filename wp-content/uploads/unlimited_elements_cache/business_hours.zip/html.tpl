<div id="{{uc_id}}" class="ue_business_hours">

  {% if show_header == "true" %}
  <div class="ue_business_hours_header">
    <div class="ue_business_hours_header_title">{{title|raw}}</div>
    <div class="ue_business_hours_header_subtitle">{{subtitle|raw}}</div>
  </div>
  {% endif %}	
  
  <div class="ue_business_hours_list">
    {{put_items()}}
  </div>
  
  {% if show_footer == "true" %}
  <div class="ue_business_hours_footer">
    {{footer_text|raw}}
  </div>
  {% endif %}
</div>

<!-- -->