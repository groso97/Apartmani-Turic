{% if add_background == "true" %}
  <div class="container_{{uc_id}}">
     <div class="ue-play-bg" id="ue-play-bg_{{uc_id}}" style="--imgurl: url({{background_image}}); background-image: linear-gradient({{background_overlay}}, {{background_overlay}}), var(--imgurl);">
{% endif %}	
     <div id="{{uc_id}}" class="ue_play_button" data-path="{{video}}">
   {% if video == "self_hosted" %}
       <a href="{{self_hosted_video_link}}" class="button_{{uc_id}}" data-lity>
   {% else %}
       <a href="{{video}}{{code}}&autoplay={{autoplay}}&mute=1" class="button_{{uc_id}}" data-lity>
   {% endif %}
      <span class="video-button">
          {{icon_html|raw}}
  </span>  
</a>
</div>
{% if add_background == "true" %}</div></div>{% endif %}