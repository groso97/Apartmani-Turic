#{{uc_id}}
{
  display:{{layout}};
  flex-wrap: wrap;
}

#{{uc_id}} a
{
  display:block;
  text-decoration:none;
  transition:0.3s;

}

#{{uc_id}} .blox_btn_group_inner
{
  display:inline-flex;
  align-items:center;
}

#{{uc_id}} .blox_btn_group_inner .ue-btn-icon
{
  line-height:1em;
}

#{{uc_id}} .blox_btn_group_inner .ue-btn-icon svg
{
  height:1em;
  width:1em;
}