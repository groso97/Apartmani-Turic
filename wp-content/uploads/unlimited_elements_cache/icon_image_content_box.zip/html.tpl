<div class="uc_icon_image_content_box" id="{{uc_id}}">	
        <div class="uc_content_box_area" >
          
			{% if badge_text is empty %}{% else %} 
                <div class="ue_badge">{{badge_text|raw}}</div>  
            {% endif %}	          
          
            <div class="uc_thumb">
                <a href="{{button_url}}" {{button_url_html_attributes|raw}}>
            		<img src="{{box_image}}" alt="{{box_image_alt}}">
                </a>
            </div>
            <div class="uc_details">
            	<a class="uc_details-icon" href="{{button_url}}" {{button_url_html_attributes|raw}}>
                  {% if graphic_element == "icon" %}{{box_icon_html|raw}}{% endif %}
                  {% if graphic_element == "number" %}{{number|raw}}{% endif %}
                </a>
            	{% if show_title == "true" %}<a href="{{button_url}}" {{button_url_html_attributes|raw}}><div class="uc_title">{{box_title|raw}}</div></a>{% endif %}
                {% if show_text == "true" %}<div class="uc_text">{{box_content|raw}}</div>{% endif %}
                {% if show_button == "true" %}<a href="{{button_url}}" class="uc_btn"  {{button_url_html_attributes|raw}}>{{button_label|raw}}</a>{% endif %}
            </div>
        </div>
</div>