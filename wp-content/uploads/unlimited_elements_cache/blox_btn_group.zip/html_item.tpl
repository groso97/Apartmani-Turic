<a class="{{item.item_repeater_class}} {{hover_effect}}" href="{{item.link|raw}}" id="{{item.item_id}}" {{item.link_html_attributes|raw}}>
  <div class="blox_btn_group_inner">
    {% if item.show_icon == "true" %}
    <div class="ue-btn-icon">{{item.icon_html|raw}}</div>
    {% endif %}
    <div class="ue-btn-txt">{{item.title|raw}}</div>
  </div>
</a>