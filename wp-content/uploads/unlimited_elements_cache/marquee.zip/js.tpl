{% if infinite_text_effect == "true" %}
{{ ucfunc("put_docready_start") }}
		
   var objListMarquee = jQuery("#{{uc_id}}");
   
   function cloneItems(){
   
      var objItemsWrapper = objListMarquee.find(".marquee_text-container");

      for(let i=0; i<3; i++){

          var objItemsCloned = objListMarquee.find(".marquee_text").clone();      
          objItemsWrapper.append(objItemsCloned);

      }    
   }
   
   cloneItems();
    	
{{ ucfunc("put_docready_end") }}
{% endif %}