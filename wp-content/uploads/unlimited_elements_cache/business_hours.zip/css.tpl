#{{uc_id}}
{
  overflow:hidden;
}
#{{uc_id}} .ue_business_hours_list_item
{
  display:flex;
  align-items:center;
  width:100%;
}

#{{uc_id}} .ue_business_hours_list_item_title
{
  flex-grow:0;
  flex-shrink:0;
}

#{{uc_id}} .ue_business_hours_list_item_text
{
  flex-grow:0;
  flex-shrink:0;
}

#{{uc_id}} .ue_business_hours_list_item_line
{
  flex-grow:1;
}

#{{uc_id}} .ue_business_hours_list_item_seperator:last-child
{
  display:none;
}

#{{uc_id}} .ue_business_hours_list_item_line
{
  width:100%;
}

.ue_business_hours_header_title
{
  font-size:21px;
}