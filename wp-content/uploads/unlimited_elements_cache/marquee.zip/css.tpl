#{{uc_id}}{
    box-sizing: border-box;
    white-space: nowrap;
    overflow: hidden;
    box-sizing: border-box;
    margin:0 auto;
    display: flex;
}

#{{uc_id}} .marquee_text {
    {% if infinite_text_effect == "true" %}
      width: auto;
      display: flex;
    {% endif %}
    align-items: center;
    justify-content: center;
    transition: all 0.2s ease;
    white-space: nowrap;
}

#{{uc_id}} a{
  text-decoration:none;
}

#{{uc_id}} .marquee_text-container {
  
  animation-timing-function: linear;
  animation-iteration-count: infinite;
  
  {% if infinite_text_effect == "false" %}
  
  	display: inline-block;
    padding-left: 100%;
  
    /*right to left*/
  	{% if direction == "marquee" %}   		
  		animation-name: marquee;
  	{% endif %}
  
    /*left to right*/
  	{% if direction == "marquee_flip" %}
  		animation-name: marquee_flip;
  	{% endif %}
  
  {% endif %}
  
  /* infinite effect */
  {% if infinite_text_effect == "true" %}
  
  	display: flex;	
  
    /*right to left*/
  	{% if direction == "marquee" %} 
  		animation-name: marquee_infinite;
  	{% endif %}
  
    /*left to right*/
  	{% if direction == "marquee_flip" %}
  		animation-name: marquee_flip_infinite;
  	{% endif %}
  
  {% endif %}
  /* end infinite effect */
  
  animation-delay: 250ms;
  
}


/*right to left*/
@keyframes marquee_infinite { 
    0% { transform: translateX(0); }
    100% { transform: translateX(-50%); }
}

/*left to right*/
@keyframes marquee_flip_infinite {
    0% { transform: translateX(-50%); }
    100% { transform: translateX(0); }    
}

/*right to left*/
@keyframes marquee {  
    0% { transform: translateX(0); }
    100% { transform: translateX(-100%); }
}

/*left to right*/
@keyframes marquee_flip { 
    0% { transform: translateX(-100%); }
    100% { transform: translateX(0); }    
}