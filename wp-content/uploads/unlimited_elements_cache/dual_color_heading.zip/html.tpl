<div class="ue-dual-color-heading">
  <{{html_tag}}>
    <span class="ue-title-one">{{title_one|raw}}</span> <span class="ue-title-two">{{title_two|raw}}</span>
  </{{html_tag}}>
</div>