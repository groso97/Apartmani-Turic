<div class="ue_business_hours_list_item">
  <div class="ue_business_hours_list_item_title">{{item.title}}</div>
  <div class="ue_business_hours_list_item_line"></div>
  <div class="ue_business_hours_list_item_text">{{item.text|raw}}</div>
</div>
<div class="ue_business_hours_list_item_seperator"></div>