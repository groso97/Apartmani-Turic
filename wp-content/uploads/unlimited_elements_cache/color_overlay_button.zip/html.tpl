<div id="{{uc_id}}" class="color-overlay-button">
  <a href="{{button_link}}" class="color-overlay-link {{hover_animation}}" {{button_link_html_attributes|raw}}>
    <span class="ue-color-overlay"></span>
    <span class="ue-btn-txt">{{link_text|raw}} {% if show_icon == "true" %}{{icon_html|raw}}{% endif %}</span>
  </a>
</div>